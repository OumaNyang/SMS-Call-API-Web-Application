<?php 

	$sid = "AC7f29fc8227e1e990cc516328e416d612";

	$token = "ceee1ee2912861fed5464e133abc2550";

	$myPhone ="+12055481048";



	$AccountSid = "AC08a056f79669bbd67980101c91ec5147";

	$AuthToken = "71c06bd86dbf827cee1250bd6ed9115f";

	$my_Phone ="+12054633508";

	



	


 ?>