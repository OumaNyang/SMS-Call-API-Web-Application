
		<?php 

		include './vendor/autoload.php';
	 	include './auth/confidential.php';

		use Twilio\Rest\Client;

		use Twilio\TwiML\VoiceResponse;

		

		if (isset($_POST['hangup'])) {

		//require_once './vendor/autoload.php';
		
		$response = new VoiceResponse();

		//$response->hangup();
		
		$response->reject();

		echo $response;
	}


 ?>
