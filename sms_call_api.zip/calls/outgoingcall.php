<?php 

	 //	include './vendor/autoload.php';
	 //	include './auth/confidential.php';

		use Twilio\Rest\Client;

		

		if (isset($_POST['call'])) {

		
			$pnumber = $_POST['pnumber'];
			

			if (empty($pnumber)) {
				$msg ="Enter Phone Number " ;
				$type = "error";
			}

			else{

	
		include './auth/confidential.php';

		


		require_once "./vendor/autoload.php";
		
	//	use Twilio\Rest\Client;

		
		$client= new Client($AccountSid,$AuthToken);

		try{
		$call = $client->calls->create(

			$pnumber,$my_Phone,
			array("url"=>"http://demo.twilio.com/docs/voice.xml")

			


		);
			$msg ="Calling".$pnumber;
			$type ="success";


		}
		catch(Exeption $e){

			$msg ="Call not sent".$e->getMessage();
			$type ="error";


		}
	}
}



 ?>