<!DOCTYPE html>
<html>
<head>
	<title>Send Message</title>
	<!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">  -->

	<link rel="stylesheet" type="text/css" href="/assets/bootstrap/css/bootstrap.min.css">
	

	</head>
	<body>

	<style type="text/css">
	.success {

		background-color: #49AE2B;
		border-radius: 2px solid green;
		border-radius: 5px;
		align-content: center;
		text-align: center;
		padding: 4px;
		font-family: Arial;
		color: #000;

	}

	.error {

		background-color: #D22828;
		border-radius: 2px solid red;
		border-radius: 5px;
		align-content: center;
		text-align: center;
		padding: 4px;
		font-family: Arial;
		color: #fff;
		

	}
		

	</style>


	<?php

	 $msg = "";
	 $type = "";

	 include './sendsms/sms.php';

	// include './sendsms/makecall.php';

	 include './calls/outgoingcall.php';

	 include './calls/hangup.php';

	 ?>

	<form  action="" method="post">
		

	<div style="margin-top: 50px;border:2px solid #0080FF;padding: 12px;width: 40%;margin-right: auto;margin-left: auto;box-shadow: none;border-radius: 8px;" class="container">
		<div class="">
			<h5 class="align-centre">Sending  SMS using Twilio</h5><br>

			<div class= <?php echo $type  ?>> <?php echo $msg;?></div>


		<label  for="phone number" >Enter phone number</label>

		<input class="form-control" type="text" name="pnumber" autocomplete="off">


		<label  for="message" >Message</label>

		<textarea style="height: 150px;box-shadow: none;" class="form-control" id="message"  name="message" placeholder="Write Message..."></textarea> 
	<div>
		<input style="margin-top: 10px;" type="submit" class="btn btn-primary" name="sendsms" value="send SMS"> 

		<input style="margin-top: 10px;" type="submit" class="btn btn-primary align-centre" name="call" value="Call">

		<input style="margin-top: 10px;" type="submit" class="btn btn-danger align-centre" name="hangup" value="EndCall">
	</div>


	</div>
</form>


   <script>
            window.onload = function() {
                history.replaceState("", "", "./sendsms.php");s
            }
            </script>

     <script src="https://code.jquery.com/jquery-2.1.1.min.js"
        type="text/javascript"></script>


</body>
</html>




















