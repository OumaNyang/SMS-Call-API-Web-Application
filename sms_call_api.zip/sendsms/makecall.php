<?php

		include './vendor/autoload.php';
		include './auth/confidential.php';
		use Twilio\Rest\Client;


		if (isset($_POST['call'])) {

			$pnumber = $_POST['pnumber'];
			
			if (empty($pnumber)) {
				$msg ="Enter Phone Number " ;
				$type = "error";
			}
			

			else{

			$client = new Twilio\Rest\Client($sid, $token);

			// Read TwiML at this URL when a call connects (hold music)

			$call = $client->calls->create(
			  $pnumber, 
			  $myPhone, 

			//  ["url" => "http://demo.twilio.com/docs/voice.xml"]



			  [

			      'url' => 'https://twimlets.com/holdmusic?Bucket=com.twilio.music.ambient'
			  ]  



			);
}
}

