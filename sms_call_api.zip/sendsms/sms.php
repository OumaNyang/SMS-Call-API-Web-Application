<?php 

	 	include './vendor/autoload.php';
	 	include './auth/confidential.php';

		

		if (isset($_POST['sendsms'])) {



			$pnumber = $_POST['pnumber'];
			$message = $_POST['message'];

			if (empty($pnumber)) {
				$msg ="Enter Phone Number " ;
				$type = "error";
			}
			elseif (empty($message)) {
				$msg ="Enter Message Body " ;
				$type = "error";
			}


			else{

			$client = new Twilio\Rest\Client($sid, $token);
			$message = $client->messages->create(
			  $pnumber, // Text this number
			  [
			    'from' => $myPhone, // From a valid Twilio number
			    'body' => $message
			  ]
			);

			if ($message) {

			$msg ="Message sent successfully to "  .$pnumber ;
			$type = "success";
				
			}

			else{

				$msg ="Message sending to".$pnumber. " failed.Kindly check the phone number and try again." ;

				$type="error";

			}
		}

	
		}

			?>


