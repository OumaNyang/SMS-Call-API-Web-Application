<?php 
header("content-type:text/xml")

 ?>

 <Response>

 	<Say> Hello Thank you for calling Eng. Ouma Nyang.. </Say>

 	


 </Response>
